from selenium import webdriver
from selenium.webdriver.common.keys import Keys
import time
import unittest

class IntegrationTest(unittest.TestCase):
    def setUp(self):
        self.driver = webdriver.Chrome()  # Make sure chromedriver is installed and in PATH

    def test_integration_index_to_result(self):
        driver = self.driver
        driver.get("http://127.0.0.1")  # Open the Nginx home page

        # Test valid input
        valid_input = "ValidPass123"
        input_field = driver.find_element_by_id("password")
        input_field.send_keys(valid_input)
        input_field.send_keys(Keys.RETURN)
        time.sleep(3)  # Wait for redirection
        self.assertIn("result.html", driver.current_url)
        self.assertIn(valid_input, driver.page_source)

        driver.get("http://127.0.0.1")  # Go back to home page

        # Test XSS input
        xss_input = "<script>alert('XSS');</script>"
        input_field = driver.find_element_by_id("password")
        input_field.send_keys(xss_input)
        input_field.send_keys(Keys.RETURN)
        time.sleep(1)  # Wait for validation
        self.assertNotIn("result.html", driver.current_url)
        self.assertIn("Potential XSS attack detected. Input cleared.", driver.page_source)

        driver.get("http://127.0.0.1")  # Go back to home page

        # Test SQL Injection input
        sql_input = "' OR 1=1; --"
        input_field = driver.find_element_by_id("password")
        input_field.send_keys(sql_input)
        input_field.send_keys(Keys.RETURN)
        time.sleep(1)  # Wait for validation
        self.assertNotIn("result.html", driver.current_url)
        self.assertIn("Potential SQL Injection attack detected. Input cleared.", driver.page_source)

    def tearDown(self):
        self.driver.close()

if __name__ == "__main__":
    unittest.main()
