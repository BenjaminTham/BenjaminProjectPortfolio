# test_ui.py
from selenium import webdriver
from selenium.webdriver.common.by import By
import time

# Path to the ChromeDriver executable
driver_path = '/path/to/chromedriver'

# Initialize the ChromeDriver
driver = webdriver.Chrome(executable_path=driver_path)

try:
    # Open the login page
    driver.get('http://localhost')

    # Find the password input field and submit button
    password_input = driver.find_element(By.ID, 'password')
    submit_button = driver.find_element(By.XPATH, '//button[@type="submit"]')

    # Test a valid password
    password_input.send_keys('ValidPass123')
    submit_button.click()
    time.sleep(2)  # Wait for the page to load
    assert 'Password is valid.' in driver.page_source

    # Test an XSS input
    password_input.clear()
    password_input.send_keys('<script>alert("XSS");</script>')
    submit_button.click()
    time.sleep(2)  # Wait for the page to load
    assert 'Potential XSS attack detected. Input cleared.' in driver.page_source

    # Test an SQL injection input
    password_input.clear()
    password_input.send_keys("' OR 1=1; --")
    submit_button.click()
    time.sleep(2)  # Wait for the page to load
    assert 'Potential SQL Injection attack detected. Input cleared.' in driver.page_source

finally:
    # Close the browser
    driver.quit()
