# Jenkins Dependecy Check Test
Project for testing the integration of the OWASP Dependency Check plugin in Jenkins.

Buliding this project in Jenkins with the plugin enabled and working will result in two medium severity findings.
