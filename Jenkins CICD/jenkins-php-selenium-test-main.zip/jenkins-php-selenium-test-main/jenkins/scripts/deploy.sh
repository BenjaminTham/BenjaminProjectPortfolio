#!/usr/bin/env sh

set -x

# Ensure the script has executable permissions
chmod +x $0

# Remove any existing container with the same name
docker rm -f my-apache-php-app || true

# Run the Docker container using host network
docker run -d --name my-apache-php-app --network host -v $(pwd)/src:/var/www/html php:7.2-apache

# Set permissions on the web content directory
docker exec my-apache-php-app chmod -R 755 /var/www/html

# Create or modify the Apache configuration file using a heredoc
docker exec my-apache-php-app bash -c 'cat <<EOF > /etc/apache2/sites-available/000-default.conf
<VirtualHost *:80>
    DocumentRoot /var/www/html
    <Directory "/var/www/html">
        Options Indexes FollowSymLinks
        AllowOverride None
        Require all granted
    </Directory>
    ErrorLog \${APACHE_LOG_DIR}/error.log
    CustomLog \${APACHE_LOG_DIR}/access.log combined
</VirtualHost>
EOF'

# Restart Apache to apply the configuration changes
docker exec my-apache-php-app apachectl restart

# Check if the container was created successfully
if [ $? -ne 0 ]; then
  echo "Failed to start Docker container"
  exit 1
fi

# Wait a few seconds to ensure the container starts
sleep 10

# Check the status of the container
docker ps -a
docker logs my-apache-php-app

set +x

echo 'Now...'
echo 'Visit http://localhost to see your PHP application in action.'
