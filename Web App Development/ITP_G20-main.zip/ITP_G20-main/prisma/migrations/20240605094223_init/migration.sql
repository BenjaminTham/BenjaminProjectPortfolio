/*
  Warnings:

  - You are about to drop the column `time_loaned` on the `Tray` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "Tray" DROP COLUMN "time_loaned";
