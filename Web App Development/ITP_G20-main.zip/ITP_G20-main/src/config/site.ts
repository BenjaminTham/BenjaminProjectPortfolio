export const siteConfig = {
    name: "SIT-RIFD",
}

export type SiteConfig = typeof siteConfig