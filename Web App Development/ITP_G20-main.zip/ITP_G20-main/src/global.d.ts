declare global {
    var lastMessageTime: Date;
}

export { };